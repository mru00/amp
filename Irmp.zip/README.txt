IRMP - Infrared Multi Protocol Decoder
--------------------------------------

Version IRMP:  1.7.2  01.07.2010
Version IRSND: 1.7.0  25.06.2010

Dokumentation:
 
   http://www.mikrocontroller.net/articles/IRMP
